# Uwulang

Uwulang is a playful uwu-ified Python based language with curly braces.

## Installation

```bash
```bash
pip install uwulang
```
```
```
```
```

## Usage

Create a new uwu file:

```bash
uwu new hewo.uwu
```

Run your uwu file:

```bash
uwu run hewo.uwu
```

